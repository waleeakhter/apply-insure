import {Component} from '@angular/core';

@Component({
  selector: 'logo, mdb-navbar-brand',
  template: `<ng-content></ng-content>`
})
export class LogoComponent {

}
