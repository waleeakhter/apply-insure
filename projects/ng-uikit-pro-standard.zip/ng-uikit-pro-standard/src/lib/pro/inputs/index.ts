
export { CharCounterDirective } from './char-counter.directive';
export { CharCounterModule } from './char-counter.module';
